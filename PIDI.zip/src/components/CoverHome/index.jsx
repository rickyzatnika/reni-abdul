import React from "react";

const CoverHome = () => {
  return <div>CoverHome TEST</div>;
};

export default CoverHome;
